/*
 * CS2333 HW1 Part 1
 *Yuan Wang
 *
 */

#include <stdio.h>
#include <time.h>

float linearFunction(void)
{
    clock_t start1, end1;
	unsigned long micros1 = 0.0;
	float millis1 = 0.0;
	int N = 10000;
	int i;

	start1 = clock();

    double sum1 = 0;
    for (i = 0; i <= N; i++)
    {
        sum1 += i;
    }

    end1 = clock();

	micros1 = end1 - start1;
	millis1 = micros1 / 1000.0;

	return millis1;
}

float quadraticFunction(void)
{
	clock_t start2, end2;
    unsigned long micros2 = 0.0;
	float millis2 = 0.0;
    int N = 10000;
	int i, j;

	start2 = clock();

    double sum2 = 0;
    for (i = 0; i <= N; i++)
    {
        for(j = 0; j <= N; j++)
        {
            sum2 += j;
        }
    }

    end2 = clock();

	micros2 = end2 - start2;
	millis2 = micros2 / 1000.0;

    return millis2;
}

float cubicFunction(void)
{
    clock_t start3, end3;
    unsigned long micros3 = 0.0;
	float millis3 = 0.0;
    int N = 10000;
	int i, j, k;

	start3 = clock();

    double sum3 = 0;
    for (i = 0; i <= N; i++)
    {
        for(j = 0; j <= N; j++)
        {
            for(k = 0; k <= N; k++)
            {
                sum3 += k;
            }
        }
    }

    end3 = clock();

	micros3 = end3 - start3;
	millis3 = micros3 / 1000.0;

	return millis3;
}

int main(void)
{
    int numOfFunction;
    float result1, result2, result3;
    
    printf("Here are the instructions:\n");
    printf("1: Linear Function.\n");
    printf("2: Quadratic Function.\n");
    printf("3: Cubic Function.\n");
    printf("Please enter the function you what to use:\n");
    
    scanf("%d", &numOfFunction);

    if(numOfFunction == 1)
    {
        result1 = linearFunction();
        printf("It took %f milliseconds.\n", result1);
    }

    if(numOfFunction == 2)
    {
        result2 = quadraticFunction();
        printf("It took %f milliseconds.\n", result2);
    }

    if(numOfFunction == 3)
    {
        result3 = cubicFunction();
        printf("It took %f milliseconds.\n", result3);
    }

    return 0;
}
