#include <stdio.h>
#include <stdlib.h>


int search(int arr[], int length, int key, int *count) {

    // the low and high index of the arr, that we want the find
    int low = 0;
    int high = length-1;

    while (low <= high) {
        (*count)++;
        int t = low + (high-low)/3;
        if (key == arr[t]) {
            return t;
        } else if (key > arr[t]) {
            low = t + 1;
        } else {
            high = t - 1;
        }

    }

    return -1;
}



int main(int argc, char *argv[]) {

    // get the key
    int key = atoi(argv[1]);
    // init the array
    int arr[200] = {0};

    int count = 0;
    for (int i = 0; i < 200; i++) {
        arr[i] = (i+1) * 2;

    }


    int index = search(arr, 200, key, &count);

    if (index != -1) {
        printf("Find the key: %d\n", key);
        printf("Number of comparisons are: %d\n", count);
        printf("The index of key is: %d\n", index);
    } else {
        printf("Cannot find the key: %d\n", key);
    }




    return 0;
}
