How to run:
	- Open a terminal
	- Go to folder with files & makefile
	- type "make"
	- In terminal(Command line)
		- to Encode
			- type: Huffman Encode < input_file_path_to_compress > path_of_output_file
		- to decompress
			- type: Huffman Decode < input_file_path_to_decompress> path_of_output_file
Note: No <> around the path_of_output_file

