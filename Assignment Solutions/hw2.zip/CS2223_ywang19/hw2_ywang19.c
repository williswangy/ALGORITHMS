#include <stdio.h>
#include <stdlib.h>

FILE *fp;

void put_file(int *array)
{
    int i = 0;
    while(i < 100)
    {
        fprintf(fp, "%d ", array[i]);
        i++;
    }
    fprintf(fp, "\n");
}

int help(int *array, int low, int high)
{
    if(low < high){

        int i = low;
        int j = high - 1;

        while(i < j)
        {
            while(array[i] <= array[high] && i != j) i++;
            while(array[j] >= array[high] && j != i) j--;
            
            if(j != i)
            {
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
                put_file(array);
            }
        }

        if(array[j] > array[high])
        {
            int temp = array[j];
            array[j] = array[high];
            array[high] = temp;
            put_file(array);
        } else
            j = high;
        
        return j;
    }
}

void quicksort(int *array, int low, int high)
{
    if(low < high)
    {
        int pivot = help(array, low, high);
        quicksort(array, low, pivot - 1);
        quicksort(array, pivot + 1, high);
    }
}

int main()
{
    int array[100];
    int i = 0;

    fp = fopen("solution.txt", "w+");

    for(i = 0; i < 100; i++)
    {
        array[i] = (rand() % 1000) + 1;
        fprintf(fp, "%d ", array[i]);
    }

    fprintf(fp, "\n");

    quicksort(array, 0, 99);

    fclose(fp);
}
